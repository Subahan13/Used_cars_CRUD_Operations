import { Component } from '@angular/core';

@Component({
  selector: 'app-homepg',
  standalone: true,
  imports: [],
  templateUrl: './homepg.component.html',
  styleUrl: './homepg.component.css'
})
export class HomepgComponent {

}
