import { Component } from '@angular/core';

@Component({
  selector: 'app-adminfooter',
  standalone: true,
  imports: [],
  templateUrl: './adminfooter.component.html',
  styleUrl: './adminfooter.component.css'
})
export class AdminfooterComponent {

}
