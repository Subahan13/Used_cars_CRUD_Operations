import { Component } from '@angular/core';

@Component({
  selector: 'app-customerfooter',
  standalone: true,
  imports: [],
  templateUrl: './customerfooter.component.html',
  styleUrl: './customerfooter.component.css'
})
export class CustomerfooterComponent {

}
