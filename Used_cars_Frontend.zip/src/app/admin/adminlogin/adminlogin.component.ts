import { Component } from '@angular/core';

@Component({
  selector: 'app-adminlogin',
  standalone: true,
  imports: [],
  templateUrl: './adminlogin.component.html',
  styleUrl: './adminlogin.component.css'
})
export class AdminloginComponent {
  username: string = '';
  password: string = '';

  //constructor(private authService: AuthService) {}

 // onSubmit() {
  //  this.authService.login(this.username, this.password);

}
