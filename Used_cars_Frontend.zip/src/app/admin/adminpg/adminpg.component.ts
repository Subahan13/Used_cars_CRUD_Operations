import { Component } from '@angular/core';

@Component({
  selector: 'app-adminpg',
  standalone: true,
  imports: [],
  templateUrl: './adminpg.component.html',
  styleUrl: './adminpg.component.css'
})
export class AdminpgComponent {

}
