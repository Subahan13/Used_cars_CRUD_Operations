import { Component } from '@angular/core';

@Component({
  selector: 'app-adminheader',
  standalone: true,
  imports: [],
  templateUrl: './adminheader.component.html',
  styleUrl: './adminheader.component.css'
})
export class AdminheaderComponent {

}
