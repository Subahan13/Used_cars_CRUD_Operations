import { Component } from '@angular/core';

@Component({
  selector: 'app-customerheader',
  standalone: true,
  imports: [],
  templateUrl: './customerheader.component.html',
  styleUrl: './customerheader.component.css'
})
export class CustomerheaderComponent {

}
