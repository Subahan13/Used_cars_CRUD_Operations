import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AngularpgComponent } from './angularpg.component';

describe('AngularpgComponent', () => {
  let component: AngularpgComponent;
  let fixture: ComponentFixture<AngularpgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AngularpgComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AngularpgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
