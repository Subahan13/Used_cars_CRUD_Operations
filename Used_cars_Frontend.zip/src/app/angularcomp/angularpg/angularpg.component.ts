import { Component } from '@angular/core';

@Component({
  selector: 'app-angularpg',
  standalone: true,
  imports: [],
  templateUrl: './angularpg.component.html',
  styleUrl: './angularpg.component.css'
})
export class AngularpgComponent {

}
