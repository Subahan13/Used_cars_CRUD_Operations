import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomserviceService
 {

  constructor(private http:HttpClient) { }

 // userexists(data:User)
  // {
  //   return this.http.post("http://localhost:8080/user/checkuser",data)            //this data represents the JSON data which we are providing earlier from RESTAPI which is our @Requestbody
  // }

}
