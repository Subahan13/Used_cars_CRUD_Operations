import { Component } from '@angular/core';

@Component({
  selector: 'app-javapg',
  standalone: true,
  imports: [],
  templateUrl: './javapg.component.html',
  styleUrl: './javapg.component.css'
})
export class JavapgComponent {

}
