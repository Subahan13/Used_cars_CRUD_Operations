import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JavapgComponent } from './javapg.component';

describe('JavapgComponent', () => {
  let component: JavapgComponent;
  let fixture: ComponentFixture<JavapgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JavapgComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(JavapgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
