import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FaqpgComponent } from './faqpg.component';

describe('FaqpgComponent', () => {
  let component: FaqpgComponent;
  let fixture: ComponentFixture<FaqpgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FaqpgComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FaqpgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
