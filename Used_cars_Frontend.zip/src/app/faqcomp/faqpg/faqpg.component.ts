import { Component } from '@angular/core';

@Component({
  selector: 'app-faqpg',
  standalone: true,
  imports: [],
  templateUrl: './faqpg.component.html',
  styleUrl: './faqpg.component.css'
})
export class FaqpgComponent {

}
