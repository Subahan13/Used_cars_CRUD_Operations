package com.Spring.fdatabase.mypack;

import java.sql.*;

public abstract class HelperBusinessCls implements Operation
{

	@Override
	public Connection connect() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void listRec() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchRec() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertRec() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteRec() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateRec() throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
