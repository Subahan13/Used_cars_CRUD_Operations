package com.Spring.fdatabase.mypack;

import java.sql.*;

public interface Operation 
{
	 Connection connect() throws SQLException,ClassNotFoundException;
	 void listRec() throws SQLException;
	 void searchRec() throws SQLException;
	 void insertRec() throws SQLException;
	 void deleteRec() throws SQLException;
	 void updateRec() throws SQLException;
	
}
