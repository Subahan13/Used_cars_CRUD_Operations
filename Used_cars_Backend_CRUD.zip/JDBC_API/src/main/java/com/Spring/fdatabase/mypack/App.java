package com.Spring.fdatabase.mypack;

import java.sql.*;

public class App 
{	
    public static void main( String[] args ) throws SQLException,ClassNotFoundException 
    {
    	DatabaseConnection obj = new DatabaseConnection();
    	Connection con = obj.connect();
    	
    	System.out.println(con!=null?"Connected":"Not Connected");
    	
    	   
    }
}
