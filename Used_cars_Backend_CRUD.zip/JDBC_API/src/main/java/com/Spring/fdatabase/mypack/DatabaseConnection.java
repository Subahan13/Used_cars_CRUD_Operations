package com.Spring.fdatabase.mypack;

import java.sql.*;


public class DatabaseConnection extends HelperBusinessCls
{
	public Connection connect() throws SQLException,ClassNotFoundException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cars","root", "root@786");  		
		return con;			
	}
	
	

}
