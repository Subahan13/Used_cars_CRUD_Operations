package Cars;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class COperations extends CHelperBusinessClass{
	
	
	public void listOfCars() throws SQLException 
	{
		Statement st = Main_Car.con.createStatement();
		
		ResultSet rs = st.executeQuery("select * from cars");
		System.out.println("\n Available cars in garage \n\n");
		while(rs.next())
		{
			
			System.out.println(String.format("%5s %-5s %-5s %-20s %-5s %-5s %-5s %-5s",
					" ",rs.getInt("car_id")," ",rs.getString("car_name")," ",rs.getInt("car_YOM")," ",rs.getInt("car_price")));
		    System.out.println(String.format("%10s %-100s"," ","_".repeat(80)));
					
		}
		rs.close();
		st.close();					
	}
	
	
	public void SearchOfCars() throws SQLException 
	{
		System.out.println("search By  (1:ID \t 2: Car Name 	 [Choices] : ");
		Statement st = Main_Car.con.createStatement();
		ResultSet rs=null;
		Scanner sc =new Scanner(System.in);
		int ch= sc.nextInt();
		switch(ch)
		{
		case 1 :
				System.out.println("\n Enter Car ID to search : ");
				int id= sc.nextInt();
				 rs= st.executeQuery("select * from cars where car_id =  "+id);
				System.out.println("\n Record is - \n\n");
				while(rs.next())
				{
				    System.out.println(String.format("%10s %-100s"," ","_".repeat(70)));
					
				    System.out.println(String.format("%10s %-5s %-5s %-20s %-5s %-5s %-5s %-5s",
							" ",rs.getInt("car_id")," ",rs.getString("car_name")," ",rs.getInt("car_YOM")," ",rs.getInt("car_price")));
				    
				    System.out.println(String.format("%10s %-100s"," ","_".repeat(70)));
							
				}
					
				break;
		case 2:
						
			System.out.println("S\nEnter \"TEXT\" to search from car name : ");
			String txt = sc.next();
			rs = st.executeQuery("select * from cars where car_name like '%"+ txt +"%'");
			System.out.println("\n Record is - \n\n");
			while(rs.next())
			{							
				System.out.println(String.format("%10s %-5s %-5s %-20s %-5s %-5s %-5s %-5s",
						" ",rs.getInt("car_id")," ",rs.getString("car_name")," ",rs.getInt("car_YOM")," ",rs.getInt("car_price")));
			    
			    System.out.println(String.format("%10s %-100s"," ","_".repeat(70)));
						
			}
										
				break;
		}
		
		sc.close();	
		rs.close();
		st.close();
	}
	
	public void InsertCars(String carnm,int carYOM, int carprc) throws SQLException 
	{
		PreparedStatement ps =Main_Car.con.prepareStatement("insert into cars(car_name,car_YOM,car_price) values (?,?,?)");
		ps.setString(1, carnm);
		ps.setInt(2, carYOM);
		ps.setInt(3,carprc);
		int i = ps.executeUpdate();
		System.out.println(i+" Car records are entered  !");	
	}
	
	public void DeleteCars(int car_id) throws SQLException
	{
		PreparedStatement ps = Main_Car.con.prepareStatement("delete from cars where car_id=?");
		ps.setInt(1, car_id);			
		int i = ps.executeUpdate();
		System.out.println(i+" Car records are removed !");
	}
	
	public void UpdateCars(int carprc, int carYOM,int car_id) throws SQLException 
	{

		PreparedStatement ps = Main_Car.con.prepareStatement("update cars set car_price=?,car_YOM=? where car_id=?");
		ps.setInt(1,car_id);
		ps.setInt(2,carYOM );
		ps.setInt(3,carprc);
		
		
		int i = ps.executeUpdate();
		System.out.println(i+" Car records are updated !");
	}

	
}
