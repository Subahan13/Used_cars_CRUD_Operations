package Cars;

import java.sql.Connection;
import java.sql.SQLException;

public interface OperationsInterface {
	
	
	Connection connect () throws SQLException , ClassNotFoundException;
	void Carslists() throws SQLException;
	void SearchOfCars() throws SQLException;
	void InsertCars(String carnm,int carpr, int carYOM) throws SQLException;
	void UpdateCars(int carpr, int carYOM,int car_id) throws SQLException;
	void DeleteCars(int car_id) throws SQLException;
	

}
