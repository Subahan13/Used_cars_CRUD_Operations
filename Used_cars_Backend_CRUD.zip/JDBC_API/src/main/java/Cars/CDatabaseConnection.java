package Cars;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CDatabaseConnection extends CHelperBusinessClass {
	
	public Connection connect() throws SQLException , ClassNotFoundException
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carsdb","root","root@786");
		if(con != null)
			System.out.println("Database connected successfully !");
		else
			System.out.println("Database is not connected");
		
		return con;
	}
	
	

}
