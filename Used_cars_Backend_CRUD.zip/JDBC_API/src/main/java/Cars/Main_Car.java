package Cars;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;



public class Main_Car 
{
	public static Connection con;
	
	
	
	  static {
	  
	  try { con = new CDatabaseConnection().connect(); } catch
	  (ClassNotFoundException e) {e.printStackTrace();} catch (SQLException e)
	  {e.printStackTrace();}
	  
	  }
	  
	  
	  static int carsList()
		{
			int ch;
			System.out.println(String.format("%35s", "Cars Mela"));
			System.out.println(String.format("%50s", "_".repeat(40)));
			System.out.println(String.format("%20s %-20s"," ", "1: List of Cars "));
			System.out.println(String.format("%20s %-20s", " ","2: Search for the car"));
			System.out.println(String.format("%20s %-20s", " ","3: Add new cars to Garage"));
			System.out.println(String.format("%20s %-20s", " ","4: Update to the car record"));
			System.out.println(String.format("%20s %-20s", " ","5: Delete the car record"));
			System.out.println(String.format("%20s %-20s", " ","Enter Choice : "));
			Scanner sc = new Scanner(System.in);
			ch= sc.nextInt();
				
			return ch;		
		}
	 
	
	
	@SuppressWarnings("resource")
	public static void main( String[] args ) throws SQLException, ClassNotFoundException
    {
		
		COperations co = new  COperations();
		
		int carchoice = carsList();
    	Scanner sc = new Scanner(System.in);
    	
    	switch(carchoice)
    	{
    	case 1: 
    			co.listOfCars();
    			break;
    			
    	case 2:
				co.SearchOfCars();
				break;
				
    	case 3: 
    		System.out.println("\nEnter Car name :");
			String carnm = sc.nextLine();
			    			    	    			    		
			System.out.println("\nEnter year of manufacture :");
			int carprc = sc.nextInt();
			
			System.out.println("\nEnter price :");
			int carYOM = sc.nextInt();
			
			co.InsertCars(carnm, carprc, carYOM);
			
			break; 
			
    	case 4:
    		System.out.println("\nEnter car id to update :");
			int id = sc.nextInt();
			System.out.println("\nEnter new YOM :");
			int q = sc.nextInt();
			System.out.println("\nEnter new price :");
			int p = sc.nextInt();
			
			co.UpdateCars(id, q,p);
			break;
    		
    	case 5:
    			System.out.println("\nEnter car id to delete :");
    			int i = sc.nextInt();
    			
    			co.DeleteCars(i);
    			break;
		
    	}
    }
}
