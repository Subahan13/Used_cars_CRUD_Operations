package Cars;

import java.sql.Connection;
import java.sql.SQLException;

public abstract class CHelperBusinessClass implements OperationsInterface 
{
	@Override
	public Connection connect() throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	public void Carslists() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void SearchOfCars() throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void InsertCars(String carnm,int carprc, int carYOM) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void DeleteCars(int car_id) throws SQLException {
		// TODO Auto-generated method stub
		
	}
	
	public void UpdateCars(int carprc, int carYOM,int car_id) throws SQLException {
		
	}
	


}
